function somar() {
    let n1 = Number(window.prompt('Digite um número:'))
    let n2 = Number(window.prompt('Digite outro número:'))

    let res = document.querySelector('section#res')
    res.innerHTML = `<span> A soma entre ${n1} e ${n2} é igual a ${n1+n2}<\span>`
}
function subtracao() {
    let n3 = Number(window.prompt('Digite um número:'))
    let n4 = Number(window.prompt('Digite outro número:'))

    let res1 = document.querySelector('section#res')
    res.innerHTML = `<span> A subitracao entre ${n3} e ${n4} é igual a ${n3-n4}<\span>`
}
function divisao() {
    let n5 = Number(window.prompt('Digite um número:'))
    let n6 = Number(window.prompt('Digite outro número:'))

    let res1 = document.querySelector('section#res')
    res.innerHTML = `<span> A divisao entre ${n5} e ${n6} é igual a ${n5/n6}<\span>`
}
function multiplicar() {
    let n7 = Number(window.prompt('Digite um número:'))
    let n8 = Number(window.prompt('Digite outro número:'))

    let res1 = document.querySelector('section#res')
    res.innerHTML = `<span> A multiplicacao entre ${n7} e ${n8} é igual a ${n7*n8}<\span>`
}
function media() {
    let nome = window.prompt("Qual o seu nome?")
    let n9 = Number(window.prompt('Digite a primeira nota:'))
    let n10 = Number(window.prompt('Digite a segunda nota:'))

    med = (n9 + n10) / 2

    let msg
    if(med>=5){
        msg = 'Aprovado'
    }else{
        msg = 'Reprovado'
    }

    let res = document.getElementById('situacao')
    res.innerHTML = `Olá, ${nome}. Sua média foi ${med}`
    res.innerHTML = `<p> A mensagem que temos é: <h1 style="color: red">${msg}</h1></p>`
}